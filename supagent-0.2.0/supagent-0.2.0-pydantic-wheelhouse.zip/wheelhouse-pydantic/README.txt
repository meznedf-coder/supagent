pydantic for Superset 6.0 (Superset 6.1 already has it)

Offline install of supagent on Superset 6.0, Python 3.10 / 3.11 / 3.12, Linux x86_64:
  unzip supagent-0.2.0-pydantic-wheelhouse.zip
  $PY -m pip install --no-index --find-links ./wheelhouse-pydantic supagent-0.2.0-py3-none-any.whl
