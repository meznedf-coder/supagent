"""The Superset tools the agent uses most, in-process (no MCP service needed): SQL, databases,
datasets. Same names and request shapes as Superset's MCP tools; Superset's own checks decide
what the user may see (raise_for_access for SQL, database / dataset access for the lists)."""

from __future__ import annotations

import datetime as dt
import decimal
import math
import re
import time
from typing import Any

from pydantic import BaseModel, Field

from supagent.tools import TABLE_ERROR, _as_user, _run, agent_databases, mcp, unknown_tables


def _plain(v: Any) -> Any:
    if isinstance(v, (dt.datetime, dt.date)):
        return v.isoformat(sep=" ") if isinstance(v, dt.datetime) else v.isoformat()
    if isinstance(v, decimal.Decimal):
        return float(v)
    if isinstance(v, float) and not math.isfinite(v):
        return None
    if isinstance(v, (bytes, bytearray)):
        return v.hex()
    return v


# What each connector can run, shown next to its databases (list_databases) and with its refusals
SQL_RULES = {
    "osagg": ("Not full SQL: OpenSearch runs the WHERE filters and the GROUP BY / aggregates. One index per query; "
              "WHERE with =, IN, ranges, LIKE, IS NULL on single fields joined by AND / OR (pairs of values: "
              "(A = x AND B = y) OR ..., never (A, B) IN ...); "
              "row lists filtered, with ORDER BY and LIMIT; the latest per key = GROUP BY key with MAX(timestamp); "
              "JOIN only in aggregating queries on equal fields. No subquery, WITH, window function or self-join "
              "over raw rows (refused above a few thousand documents): work in steps, WHERE key IN (values found "
              "by the previous query)."),
    "promagg": ("Not full SQL: turned into PromQL. One metric table per query, a ts range, GROUP BY a time bucket "
                "and labels, SUM(rate) / SUM(increase) / AVG(value) / MAX(value) / HISTOGRAM_QUANTILE. No row-by-row "
                "join of metrics, no WITH, window function or subquery over raw samples, no quantile of raw "
                "samples, no filter on the value (HAVING): promql_query for arithmetic between metrics."),
}
WHERE_HINT = (" Do not send this query again, nor a variant of it: its WHERE has a condition OpenSearch cannot run, "
              "so every document would be read. Use only =, IN, ranges, LIKE, IS NULL on single fields, joined by "
              "AND / OR; for pairs of values write (\"A\" = 'x' AND \"B\" = 'y') OR (\"A\" = 'z' AND \"B\" = 'w') "
              "in one query.")
STEPS_HINT = (" Do not send this query again, nor a variant of it: rewrite it in steps. 1) One query for the few keys "
              "you need (ids, dates), filtered, with GROUP BY the key and MAX of the timestamp for the latest one. "
              "2) One query per index with WHERE key IN (the values found), with a LIMIT. Then put the results "
              "together in your answer.")


class ExecuteSqlRequest(BaseModel):
    database_id: int = Field(description="Database id (list_databases)")
    sql: str = Field(description="One SELECT statement")
    limit: int = Field(default=1000, description="Rows returned at most (at most 10000)")


@mcp.tool
def execute_sql(request: ExecuteSqlRequest) -> dict:
    """Run one SELECT on a database, with your permissions, and return its rows."""
    t0 = time.time()
    try:
        with _as_user():
            from superset.extensions import db
            from superset.models.core import Database

            database = db.session.get(Database, int(request.database_id))
            if database is None or not agent_databases([database]):
                return {"success": False, "error": f"database {request.database_id} not found or not one the agent "
                                                   "may use (list_databases)"}
            limit = max(1, min(int(request.limit or 1000), 10000))
            from supagent.knowledge.experience import guard_sql

            refused = guard_sql(database, request.sql)
            if refused:
                return {"success": False, "error": refused}
            backend = database.backend
            try:
                columns, rows, truncated = _run(database, request.sql, limit, extract=False)
            except Exception as ex:  # pylint: disable=broad-except
                text = f"{type(ex).__name__}: {str(ex)[:1500]}"
                hint = unknown_tables(database, request.sql) if TABLE_ERROR.search(text) else ""
                if hint:                               # the real cause: a name that is no index or metric
                    return {"success": False, "error": f"{hint} ({text[:300]})"}
                if backend == "osagg" and "WHERE term evaluated" in text:
                    text += WHERE_HINT
                elif backend == "osagg" and re.search(r"pushed down|cannot run in OpenSearch|JoinRefused|safety cap",
                                                      text):
                    text += STEPS_HINT
                elif backend in SQL_RULES and re.search(r"not possible|not supported|unsupported|cannot|refused",
                                                        text, re.I):
                    text += " What this database can run: " + SQL_RULES[backend]
                return {"success": False, "error": text}
            return {"success": True, "database": database.database_name,
                    "columns": [{"name": c} for c in columns],
                    "rows": [{c: _plain(v) for c, v in zip(columns, r)} for r in rows],
                    "row_count": len(rows), "truncated": truncated, "seconds": round(time.time() - t0, 2),
                    "error": None}
    except Exception as ex:  # pylint: disable=broad-except
        return {"success": False, "error": f"{type(ex).__name__}: {str(ex)[:1500]}"}


@mcp.tool
def list_databases() -> dict:
    """The databases you may query: id, name, engine (osagg = OpenSearch indices, promagg =
    Prometheus / Mimir metrics)."""
    with _as_user():
        from superset.extensions import db, security_manager
        from superset.models.core import Database

        out = []
        for d in agent_databases(list(db.session.query(Database).order_by(Database.id))):
            if security_manager.can_access_database(d):
                item = {"id": d.id, "name": d.database_name, "backend": d.backend,
                        "kind": {"osagg": "OpenSearch indices", "promagg": "Prometheus / Mimir metrics"}.get(
                            d.backend, d.backend)}
                if d.backend in SQL_RULES:
                    item["sql"] = SQL_RULES[d.backend]
                out.append(item)
        return {"databases": out}


class ListDatasetsRequest(BaseModel):
    search: str | None = Field(default=None, description="Part of the dataset name")
    database_id: int | None = Field(default=None, description="Only this database")
    page_size: int = Field(default=50, description="Datasets returned at most")


@mcp.tool
def list_datasets(request: ListDatasetsRequest | None = None) -> dict:
    """Superset datasets you may use (for charts): id, name, database."""
    request = request or ListDatasetsRequest()
    with _as_user():
        from superset.connectors.sqla.models import SqlaTable
        from superset.extensions import db, security_manager

        from superset.models.core import Database

        usable = [d.id for d in agent_databases(db.session.query(Database).all())] or [-1]
        q = db.session.query(SqlaTable).filter(SqlaTable.database_id.in_(usable)).order_by(SqlaTable.id)
        if request.database_id is not None:
            q = q.filter(SqlaTable.database_id == int(request.database_id))
        if request.search:
            q = q.filter(SqlaTable.table_name.ilike(f"%{request.search}%"))
        out = []
        for ds in q:
            if len(out) >= max(1, min(request.page_size, 200)):
                break
            if security_manager.can_access_datasource(ds):
                out.append({"id": ds.id, "table_name": ds.table_name, "database_id": ds.database_id,
                            "database": ds.database.database_name, "schema": ds.schema,
                            "description": (ds.description or "")[:200]})
        return {"datasets": out, "count": len(out)}


class DatasetInfoRequest(BaseModel):
    identifier: int = Field(description="Dataset id (list_datasets)")


@mcp.tool
def get_dataset_info(request: DatasetInfoRequest) -> dict:
    """A dataset's columns (name, type, time column, description) and saved metrics."""
    with _as_user():
        from superset.connectors.sqla.models import SqlaTable
        from superset.extensions import db, security_manager

        ds = db.session.get(SqlaTable, int(request.identifier))
        if ds is None or not security_manager.can_access_datasource(ds) or not agent_databases([ds.database]):
            return {"error": f"dataset {request.identifier} not found or not allowed"}
        return {"id": ds.id, "table_name": ds.table_name, "database_id": ds.database_id,
                "database": ds.database.database_name, "main_dttm_col": ds.main_dttm_col,
                "columns": [{"column_name": c.column_name, "type": c.type, "is_dttm": bool(c.is_dttm),
                             "description": c.description or ""} for c in ds.columns],
                "metrics": [{"metric_name": m.metric_name, "expression": m.expression,
                             "description": m.description or ""} for m in ds.metrics]}
